import pygame
import random
pygame.init()

BLACK=[0,0,0]
WHITE=[255,255,255]
RED=[255,0,0]
GREEN=[0,255,0]
BLUE=[0,0,255]
size=[700,400]

screen=pygame.display.set_mode(size)
pygame.display.set_caption('PING PONG')

background_image=pygame.image.load("PingPong.jpg")
background_image=pygame.transform.scale(background_image,[700,400])
bg_pos=[0,0]

font=pygame.font.Font(None,50)
score_font=pygame.font.Font(None,100)

done=False
clock=pygame.time.Clock()

class Player1(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.image.load("PingPongBar.png")
        self.image=pygame.transform.scale(self.image,[45,45])
        self.rect=self.image.get_rect()
        self.rect.x=10
        self.rect.y=200

    def update(self):
        pressed=pygame.key.get_pressed()
        if pressed[pygame.K_w]:self.rect.y-=5
        if pressed[pygame.K_s]:self.rect.y+=5

        if self.rect.y>400:
            self.rect.y-=50

        if self.rect.y<0:
            self.rect.y+=50

class Player2(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.image.load("PingPongBar.png")
        self.image=pygame.transform.scale(self.image,[45,45])
        self.rect=self.image.get_rect()
        self.rect.x=650
        self.rect.y=200

    def update(self):
        pressed=pygame.key.get_pressed()
        if pressed[pygame.K_UP]:self.rect.y-=5
        if pressed[pygame.K_DOWN]:self.rect.y+=5

        if self.rect.y>400:
            self.rect.y-=50

        if self.rect.y<0:
            self.rect.y+=50

class Ball(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self) 
        self.image=pygame.image.load("PingPongBall.png")
        self.image=pygame.transform.scale(self.image,[20,20])
        self.rect=self.image.get_rect()
        self.bx=500
        self.by=350
        self.bxc=5
        self.byc=5
        self.player1_score=0
        self.player2_score=0
        self.rect.x=self.bx
        self.rect.y=self.by


    def update(self):
        self.rect.y-=self.byc
        self.rect.x-=self.bxc

        if self.rect.y>400 or self.rect.y<0:
            self.byc*=-1

        if self.rect.x>700 or self.rect.x<0:
            self.rect.y=self.by
            self.rect.x=self.bx

        if pygame.sprite.spritecollide(self,player1_list,False):
            self.byc*=-1
            self.bxc*=-1

        if pygame.sprite.spritecollide(self,player2_list,False):
            self.byc*=-1
            self.bxc*=-1

        if self.rect.x>=700:
            self.player1_score+=1

        if self.rect.x<=0:
            self.player2_score+=1

all_sprites=pygame.sprite.Group()
player1_list=pygame.sprite.Group()
player2_list=pygame.sprite.Group()

player1=Player1()
all_sprites.add(player1)
player1_list.add(player1)

player2=Player2()
all_sprites.add(player2)
player2_list.add(player2)

ball=Ball()
all_sprites.add(ball)

while not done:

    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            done=True
    screen.fill(BLACK)
    screen.blit(background_image,bg_pos)
    all_sprites.update()
    all_sprites.draw(screen)

    scoreP1=score_font.render(str(ball.player1_score),True,BLACK)
    screen.blit(scoreP1,[25,0])

    scoreP2=score_font.render(str(ball.player2_score),True,BLACK)
    screen.blit(scoreP2,[625,0])

    if ball.player1_score==9 or ball.player1_score==9:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                done=True

    pygame.display.flip()
    clock.tick(60)
pygame.quit()
    
        














    
